#include <functional>
#include "conjunto.h"
#include "crimen.h"
#include "fecha.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <time.h>
using namespace std;
	
int main(){
	
	crimen x,y;
	

	fecha f("03/07/2012 10:45:56 AM");
	y.setDate(f);
	y.setIUCR("UNIUCRCUALQUIERA");


	conjunto< ComparacionPorFechaD > unConjunto;
	ComparacionPorFechaC miFunctorC;
	ComparacionPorFechaD miFunctorD;
	ComparacionPorIUCR miFunctorIUCR;
	
	cout<<miFunctorC(x,y) << endl;
	cout<<miFunctorC(y,x) << endl;

	cout<<miFunctorD(x,y) << endl;
	cout<<miFunctorD(y,x) << endl;

	cout<<miFunctorIUCR(x,y) << endl;
	cout<<miFunctorIUCR(y,x) << endl;

	
	


	conjunto<ComparacionPorFechaD> unConjunto1;
	conjunto<ComparacionPorIUCR> unConjunto2;
	conjunto < less<crimen> > z;

	//cout << z.size() << endl;
	//cout << unConjunto.size() << endl;
	//cout << unConjunto1.size() << endl;
	//cout << unConjunto2.size() << endl;

	return 0;
}
